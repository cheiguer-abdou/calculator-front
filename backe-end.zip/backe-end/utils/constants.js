export const OPERATION_COSTS = {
    addition: 1,
    subtraction: 1,
    multiplication: 2,
    division: 2,
    square_root: 3,
    randomString: 5
  };

export const USER_POOL_ID = "us-east-1_lXGOWZAD5";