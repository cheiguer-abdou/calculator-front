import { processOperation } from '../services/operation-service.mjs';

export const handler = async (event) => {
  const { user_id: userId } = event;
  
  return await processOperation({
    operationType: 'randomString',
    userId,
    operationFunc: async () => {
      // Fetch a random string from Random.org
      const randomString = await fetchRandomString();
      return randomString;
    }
  });
};

// Function to fetch a random string from Random.org
const fetchRandomString = async () => {
  const url = 'https://www.random.org/strings/?num=1&len=10&digits=on&upperalpha=on&loweralpha=on&unique=on&format=plain'; // Adjust the parameters based on your needs
  
  try {
    const response = await fetch(url);
    
    // Check if the response was successful (status 200)
    if (!response.ok) {
      throw new Error(`Failed to fetch random string: ${response.statusText}`);
    }
    
    const data = await response.text();  // Read response as plain text
    return data.trim();  // Return the random string
  } catch (error) {
    console.error('Error fetching random string:', error);
    throw new Error('Failed to fetch random string from Random.org');
  }
};
